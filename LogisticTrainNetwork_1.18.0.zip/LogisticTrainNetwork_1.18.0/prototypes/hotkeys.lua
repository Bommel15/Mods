data:extend{
  {
    type = "custom-input",
    name = "ltn-toggle-dispatcher",
    key_sequence = "CONTROL + SHIFT + D",
    consuming = "game-only"
  }
}